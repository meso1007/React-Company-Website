export default function NoPage(){
    return(
        <h1>404 Page not found</h1>
    )
}