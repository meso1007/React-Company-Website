export default function InfoPage(props){
    return(
        <>
            <h1>Info Page</h1>
        </>
    )
}